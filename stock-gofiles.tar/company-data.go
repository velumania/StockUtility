package main

import (
	"context"
	"encoding/csv"
	"fmt"
	"log"
	"os"
	"strings"
	"time"

	"github.com/chromedp/chromedp"
)

type CompanyData struct {
	StockSymbol         string
	ShareholdingDetails []string
	CompanyRatios       []string // Changed to slice to preserve order
}

// Fetches both shareholding information and company ratios using a single visit to the site
func fetchCompanyData(ctx context.Context, stockSymbol string) (CompanyData, error) {
	url := fmt.Sprintf("https://www.screener.in/company/%s/consolidated/", stockSymbol)

	var shareholders []string
	var ratioNames []string
	var ratioNumbers []string

	err := chromedp.Run(ctx,
		chromedp.Navigate(url),
		//chromedp.ActionFunc(func(ctx context.Context) error {
		//	return network.SetExtraHTTPHeaders(network.Headers{
		//		"User-Agent": "CustomAgent",
		//	}).Do(ctx)
		//}),
		//chromedp.ScrollIntoView(`div.company-ratios`, chromedp.ByQuery),
		//chromedp.WaitVisible(`div.company-ratios`),
		chromedp.Sleep(2*time.Second), // Allow content to load
		chromedp.Evaluate(`Array.from(document.querySelector('#quarterly-shp table.data-table tbody').querySelectorAll('tr'))
		.slice(0, 4).map(row => {
			let cell = row.querySelectorAll('td')[12];
			return cell ? cell.innerText : row.querySelectorAll('td')[1].innerText;
		})`, &shareholders),
		chromedp.Evaluate(`Array.from(document.querySelectorAll("div.company-ratios li span.name"), e => e.innerText)`, &ratioNames),
		chromedp.Evaluate(`Array.from(document.querySelectorAll("div.company-ratios li span.number"), e => e.innerText)`, &ratioNumbers),
	)
	//var rawHTML string
	//htmlerr := chromedp.Run(ctx,
	//	chromedp.InnerHTML(`div.company-ratios`, &rawHTML),
	//)
	//fmt.Println(rawHTML) // Check if this matches what you see in the browser.
	//if htmlerr != nil {
	//	return CompanyData{}, fmt.Errorf("error fetching data for %s: %w", stockSymbol, err)
	//}

	if err != nil {
		return CompanyData{}, fmt.Errorf("error fetching data for %s: %w", stockSymbol, err)
	}

	// Create a slice of combined ratios to preserve order
	combinedRatios := make([]string, 0)
	for i := 0; i < len(ratioNames) && i < len(ratioNumbers); i++ {
		combinedRatios = append(combinedRatios, fmt.Sprintf("%s: %s", ratioNames[i], strings.ReplaceAll(ratioNumbers[i], ",", "")))
	}

	return CompanyData{
		StockSymbol:         stockSymbol,
		ShareholdingDetails: shareholders,
		CompanyRatios:       combinedRatios, // Using a slice to preserve order
	}, nil
}

func main() {
	inputFile, err := os.Open("/Users/velumani.a/Downloads/stock_symbols_19022025.csv")
	if err != nil {
		log.Fatalf("Failed to open input CSV file: %v", err)
	}
	defer inputFile.Close()

	reader := csv.NewReader(inputFile)
	records, err := reader.ReadAll()
	if err != nil {
		log.Fatalf("Failed to read CSV file: %v", err)
	}

	outputFile, err := os.Create("/Users/velumani.a/Downloads/company_data_19022025.csv")
	if err != nil {
		log.Fatalf("Failed to create output CSV file: %v", err)
	}
	defer outputFile.Close()

	writer := csv.NewWriter(outputFile)
	defer writer.Flush()

	// Write header to output CSV file
	writer.Write([]string{"Stock Symbol", "Shareholding Data", "Company Ratios"})

	// Create a context with timeout to prevent hanging
	ctx, cancel := chromedp.NewContext(context.Background())
	defer cancel()

	for _, record := range records {
		stockSymbol := record[0]
		fmt.Printf("Fetching data for stock: %s\n", stockSymbol)

		data, err := fetchCompanyData(ctx, stockSymbol)
		if err != nil {
			log.Printf("Error fetching data for %s: %v", stockSymbol, err)
			continue
		}

		// Write the data to CSV
		writer.Write([]string{
			data.StockSymbol,
			strings.Join(data.ShareholdingDetails, "; "),
			strings.Join(data.CompanyRatios, "; "), // Writing in the same order as read
		})
	}

	fmt.Println("Data fetching complete. Output written to company_data.csv")
}
