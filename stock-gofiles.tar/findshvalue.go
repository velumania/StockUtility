package main

import (
	"encoding/csv"
	"fmt"
	"log"
	"os"
)

func findColumnValue(filePath, target string) (string, error) {
	// Open the CSV file
	file, err := os.Open(filePath)
	if err != nil {
		return "", fmt.Errorf("failed to open CSV file: %w", err)
	}
	defer file.Close()

	// Create a new CSV reader
	reader := csv.NewReader(file)

	// Iterate over the rows
	for {
		record, err := reader.Read()
		if err != nil {
			if err.Error() == "EOF" {
				break
			}
			return "", fmt.Errorf("error reading CSV file: %w", err)
		}

		// Check if the first column matches the target string
		if len(record) > 1 && record[0] == target {
			return fmt.Sprintf(`"%s"`, record[1]), nil // Return the value in the second column
		}
	}

	// If no match is found, return an error
	return "", fmt.Errorf("no matching row found for target: %s", target)
}

func main() {
	filePath := "/Users/velumani.a/Downloads/shareholding_data_nselist_30102024.csv" // Path to your CSV file
	target := "TRENT"                                                                // The string you want to match in the first column

	value, err := findColumnValue(filePath, target)
	if err != nil {
		log.Fatalf("Error: %v", err)
	}

	fmt.Printf("Value in column 2 for target '%s': %s\n", target, value)
}
