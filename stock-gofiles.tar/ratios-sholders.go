package main

import (
	"context"
	"encoding/csv"
	"fmt"
	"log"
	"os"
	"strings"
	"time"

	"github.com/chromedp/chromedp"
)

type CompanyData struct {
	StockSymbol         string
	ShareholdingDetails []string
	CompanyRatios       map[string]string
}

// Fetches both shareholding information and company ratios using a single visit to the site
func fetchCompanyData(ctx context.Context, stockSymbol string) (CompanyData, error) {
	url := fmt.Sprintf("https://www.screener.in/company/%s/consolidated/", stockSymbol)

	var shareholders []string
	var ratioNames []string
	var ratioNumbers []string

	err := chromedp.Run(ctx,
		chromedp.Navigate(url),
		chromedp.Sleep(3*time.Second), // Allow content to load
		// Select shareholding data from the 7th table
		//chromedp.Evaluate(`Array.from(document.querySelectorAll("table.data-table")[6].querySelectorAll("tbody tr"))
		//        .slice(0, 4).map(row => {
		//            let cell = row.querySelectorAll("td")[12];
		//            return cell ? cell.innerText : row.querySelectorAll("td")[1].innerText;
		//        })`, &shareholders),
		chromedp.Evaluate(`Array.from(document.querySelector('#quarterly-shp table.data-table tbody').querySelectorAll('tr'))
    .slice(0, 4).map(row => {
        let cell = row.querySelectorAll('td')[12];
        return cell ? cell.innerText : row.querySelectorAll('td')[1].innerText;
    })`, &shareholders),
		// Select company ratios
		chromedp.WaitVisible(`div.company-ratios`),
		chromedp.Evaluate(`Array.from(document.querySelectorAll("div.company-ratios li span.name"), e => e.innerText)`, &ratioNames),
		chromedp.Evaluate(`Array.from(document.querySelectorAll("div.company-ratios li span.number"), e => e.innerText)`, &ratioNumbers),
	)
	if err != nil {
		return CompanyData{}, fmt.Errorf("error fetching data for %s: %w", stockSymbol, err)
	}

	// Build map of ratios
	companyRatios := make(map[string]string)
	for i := 0; i < len(ratioNames) && i < len(ratioNumbers); i++ {
		companyRatios[ratioNames[i]] = strings.ReplaceAll(ratioNumbers[i], ",", "")
	}

	return CompanyData{
		StockSymbol:         stockSymbol,
		ShareholdingDetails: shareholders,
		CompanyRatios:       companyRatios,
	}, nil
}

func main() {
	inputFile, err := os.Open("/Users/velumani.a/Downloads/stock_symbols.csv")
	if err != nil {
		log.Fatalf("Failed to open input CSV file: %v", err)
	}
	defer inputFile.Close()

	reader := csv.NewReader(inputFile)
	records, err := reader.ReadAll()
	if err != nil {
		log.Fatalf("Failed to read CSV file: %v", err)
	}

	outputFile, err := os.Create("/Users/velumani.a/Downloads/company_data.csv")
	if err != nil {
		log.Fatalf("Failed to create output CSV file: %v", err)
	}
	defer outputFile.Close()

	writer := csv.NewWriter(outputFile)
	defer writer.Flush()

	// Write header to output CSV file
	writer.Write([]string{"Stock Symbol", "Shareholding Data", "Company Ratios"})

	// Create a context with timeout to prevent hanging
	ctx, cancel := chromedp.NewContext(context.Background())
	//ctx, cancel = context.WithTimeout(ctx, 15*time.Second)
	defer cancel()

	for _, record := range records {
		stockSymbol := record[0]
		fmt.Printf("Fetching data for stock: %s\n", stockSymbol)

		data, err := fetchCompanyData(ctx, stockSymbol)
		if err != nil {
			log.Printf("Error fetching data for %s: %v", stockSymbol, err)
			continue
		}

		// Convert company ratios map to a string
		var ratios []string
		for k, v := range data.CompanyRatios {
			ratios = append(ratios, fmt.Sprintf("%s: %s", k, v))
		}

		// Write the data to CSV
		writer.Write([]string{
			data.StockSymbol,
			strings.Join(data.ShareholdingDetails, "; "),
			strings.Join(ratios, "; "),
		})
	}

	fmt.Println("Data fetching complete. Output written to company_data.csv")
}
