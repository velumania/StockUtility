package main

import (
	"encoding/csv"
	"fmt"
	"log"
	"os"
	"strings"
)

func transformKey(key string) string {
	// Define a mapping of keys to their transformed values
	transformations := map[string]string{
		"Market Cap":     "MktCap",
		"Current Price":  "CP",
		"High / Low":     "HL",
		"Stock P/E":      "P/E",
		"Book Value":     "BV",
		"Dividend Yield": "DY",
		"ROCE":           "ROCE",
		"ROE":            "ROE",
		"Face Value":     "FV",
	}

	// Trim whitespace from key and check if there's a transformation defined
	trimmedKey := strings.TrimSpace(key)
	if newKey, exists := transformations[trimmedKey]; exists {
		return newKey
	}

	// If no transformation is defined, return the original key
	return trimmedKey
}

func main() {
	inputFile, err := os.Open("/Users/velumani.a/Downloads/company_ratios.csv")
	if err != nil {
		log.Fatalf("Failed to open input CSV file: %v", err)
	}
	defer inputFile.Close()

	reader := csv.NewReader(inputFile)
	records, err := reader.ReadAll()
	if err != nil {
		log.Fatalf("Failed to read CSV file: %v", err)
	}

	for _, record := range records {
		if len(record) < 1 {
			continue // Skip empty rows
		}

		// Read the input string from the first column
		inputString := record[1]
		parts := strings.Split(inputString, ",") // Split by comma

		var transformedParts []string
		for _, part := range parts {
			// Split each part by colon
			subParts := strings.SplitN(part, ":", 2)
			if len(subParts) != 2 {
				continue // Skip invalid parts that do not have exactly 2 subparts
			}

			key := strings.TrimSpace(subParts[0])
			value := strings.TrimSpace(subParts[1])

			// Transform the key using the transformKey function
			newKey := transformKey(key)

			// Reconstruct the string
			transformedPart := fmt.Sprintf("%s: %s", newKey, value)
			transformedParts = append(transformedParts, transformedPart)
		}

		// Join all transformed parts back into a single string
		resultString := strings.Join(transformedParts, ", ")
		fmt.Println("Transformed String:", resultString)
	}
}
