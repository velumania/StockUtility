package main

import (
	"context"
	"encoding/csv"
	"fmt"
	"log"
	"os"
	"strings"
	"time"

	"github.com/chromedp/chromedp"
)

type ShareholdingData struct {
	StockSymbol         string
	ShareholdingDetails string
	ShareholdingValues  string
}

// Function to fetch shareholding information for a given stock symbol using chromedp
func fetchShareholders(stockSymbol string) (ShareholdingData, error) {
	var details []string
	var values []string
	ctx, cancel := chromedp.NewContext(context.Background())
	defer cancel()

	// Define the target URL
	url := fmt.Sprintf("https://www.screener.in/company/%s/consolidated/", stockSymbol)

	// Navigate to URL and scrape data from the first four rows of the 7th table
	err := chromedp.Run(ctx,
		chromedp.Navigate(url),
		chromedp.Sleep(2*time.Second), // Wait for the page to load
		chromedp.ActionFunc(func(ctx context.Context) error {
			var rows []string
			// Select only the first four rows from the 7th table and attempt to fetch the 12th column;
			// if the 12th column is unavailable, fall back to the 1st column
			if err := chromedp.Evaluate(`Array.from(document.querySelectorAll("table.data-table")[6].querySelectorAll("tbody tr"))
                .slice(0, 4).map(row => {
                    let cell = row.querySelectorAll("td")[12];
                    return cell ? cell.innerText : row.querySelectorAll("td")[1].innerText;
                })`, &rows).Do(ctx); err != nil {
				return err
			}

			// Debugging output to verify rows
			fmt.Printf("Fetched rows (12th column, or 1st as fallback) for %s: %v\n", stockSymbol, rows)

			// Parse each row's content
			for _, value := range rows {
				details = append(details, fmt.Sprintf("Fetched Value: %s", value))
				values = append(values, value)
			}
			return nil
		}),
	)
	if err != nil {
		return ShareholdingData{}, fmt.Errorf("error loading Screener.in for %s: %w", stockSymbol, err)
	}

	// If no data found, mark as "Not Found"
	if len(details) == 0 {
		return ShareholdingData{
			StockSymbol:         stockSymbol,
			ShareholdingDetails: "Not Found",
			ShareholdingValues:  "N/A",
		}, nil
	}

	// Join all shareholding data entries with commas or newlines for clarity
	return ShareholdingData{
		StockSymbol:         stockSymbol,
		ShareholdingDetails: strings.Join(details, "\n"), // Use "\n" to make each entry in a new line
		ShareholdingValues:  strings.Join(values, ", "),
	}, nil
}

func main() {
	inputFile, err := os.Open("/Users/velumani.a/Downloads/stock_symbols.csv")
	if err != nil {
		log.Fatalf("Failed to open input CSV file: %v", err)
	}
	defer inputFile.Close()

	reader := csv.NewReader(inputFile)
	records, err := reader.ReadAll()
	if err != nil {
		log.Fatalf("Failed to read CSV file: %v", err)
	}

	outputFile, err := os.Create("/Users/velumani.a/Downloads/shareholding.csv")
	if err != nil {
		log.Fatalf("Failed to create output CSV file: %v", err)
	}
	defer outputFile.Close()

	writer := csv.NewWriter(outputFile)
	defer writer.Flush()

	// Write header to output CSV file
	writer.Write([]string{"Stock Symbol", "Shareholding Data", "Shareholding Values"})

	for _, record := range records {
		stockSymbol := record[0] // assuming the stock symbol is in the first column of each row
		fmt.Printf("Fetching data for stock: %s\n", stockSymbol)

		// Fetch shareholding data for the stock
		data, err := fetchShareholders(stockSymbol)
		if err != nil {
			log.Printf("Error fetching data for %s: %v", stockSymbol, err)
			continue
		}

		// Write the stock symbol, comma-separated shareholding data, and values to the CSV file
		writer.Write([]string{data.StockSymbol, data.ShareholdingDetails, data.ShareholdingValues})

		// Add delay to avoid hitting the server too quickly
		time.Sleep(1000 * time.Millisecond)
	}

	fmt.Println("Data fetching complete. Output written to shareholding_data.csv")
}
