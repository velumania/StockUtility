package main

import (
	"encoding/csv"
	"fmt"
	"log"
	"os"
)

func readCSVColumn(filePath string, columnIndex int) (map[string]bool, error) {
	// Open the CSV file
	file, err := os.Open(filePath)
	if err != nil {
		return nil, fmt.Errorf("failed to open CSV file: %w", err)
	}
	defer file.Close()

	// Create a CSV reader
	reader := csv.NewReader(file)

	// Read all rows
	records, err := reader.ReadAll()
	if err != nil {
		return nil, fmt.Errorf("failed to read CSV file: %w", err)
	}

	// Store values from the specified column in a map for quick lookups
	values := make(map[string]bool)
	for _, record := range records {
		if len(record) > columnIndex {
			values[record[columnIndex]] = true
		}
	}

	return values, nil
}

func main() {
	csvFile1 := "/Users/velumani.a/Downloads/shareholding_data_nselist_30102024.csv" // First CSV file path
	csvFile2 := "/Users/velumani.a/Downloads/company_data_13112024.csv"              // Second CSV file path
	outputFile := "/Users/velumani.a/Downloads/unmatched.csv"

	// Read column 1 from the first CSV file
	values1, err := readCSVColumn(csvFile1, 0)
	if err != nil {
		log.Fatalf("Error reading CSV file 1: %v", err)
	}

	// Read column 1 from the second CSV file
	values2, err := readCSVColumn(csvFile2, 0)
	if err != nil {
		log.Fatalf("Error reading CSV file 2: %v", err)
	}

	// Open the output file for writing
	output, err := os.Create(outputFile)
	if err != nil {
		log.Fatalf("Failed to create output file: %v", err)
	}
	defer output.Close()

	// Create a CSV writer
	writer := csv.NewWriter(output)
	defer writer.Flush()

	// Write unmatched values from the first CSV file to the output
	for value := range values1 {
		if !values2[value] {
			if err := writer.Write([]string{value}); err != nil {
				log.Fatalf("Failed to write to output file: %v", err)
			}
		}
	}

	fmt.Printf("Unmatched values written to %s\n", outputFile)
}
