package main

import (
	"context"
	"encoding/csv"
	"fmt"
	"log"
	"os"
	"strings"
	"time"

	"github.com/chromedp/chromedp"
)

type CompanyData struct {
	StockSymbol   string
	CompanyRatios string
}

// Function to fetch company ratios from Screener.in for a given stock symbol
func fetchCompanyRatios(stockSymbol string) (CompanyData, error) {
	ctx, cancel := chromedp.NewContext(context.Background())
	defer cancel()

	// Set up a timeout to prevent hanging
	ctx, cancel = context.WithTimeout(ctx, 15*time.Second)
	defer cancel()

	var ratios []string
	url := fmt.Sprintf("https://www.screener.in/company/%s/consolidated/", stockSymbol)

	// JavaScript to fetch names and numbers together within each <li> item
	// JavaScript to fetch names and cleaned numbers within each <li> item
	js := `
    Array.from(document.querySelectorAll("div.company-ratios li")).map(li => {
        let name = li.querySelector("span.name") ? li.querySelector("span.name").innerText : "";
        let numbers = Array.from(li.querySelectorAll("span.number")).map(span => 
            span.innerText.replace(/,/g, "") // Remove commas from numbers
        );
        return name + ": " + numbers.join(" / ");
    });
`
	// Run the JavaScript and store the result in `ratios`
	err := chromedp.Run(ctx,
		chromedp.Navigate(url),
		chromedp.WaitVisible(`div.company-ratios`, chromedp.ByQuery),
		chromedp.Evaluate(js, &ratios),
	)
	if err != nil {
		return CompanyData{}, fmt.Errorf("error fetching company ratios for %s: %w", stockSymbol, err)
	}

	// Join all ratios with commas for a single string output
	return CompanyData{
		StockSymbol:   stockSymbol,
		CompanyRatios: strings.Join(ratios, ", "),
	}, nil
}

func main() {
	inputFile, err := os.Open("/Users/velumani.a/Downloads/stock_symbols.csv")
	if err != nil {
		log.Fatalf("Failed to open input CSV file: %v", err)
	}
	defer inputFile.Close()

	reader := csv.NewReader(inputFile)
	records, err := reader.ReadAll()
	if err != nil {
		log.Fatalf("Failed to read CSV file: %v", err)
	}

	outputFile, err := os.Create("/Users/velumani.a/Downloads/company_ratios.csv")
	if err != nil {
		log.Fatalf("Failed to create output CSV file: %v", err)
	}
	defer outputFile.Close()

	writer := csv.NewWriter(outputFile)
	defer writer.Flush()

	// Write header to output CSV file
	writer.Write([]string{"Stock Symbol", "Company Ratios"})

	for _, record := range records {
		stockSymbol := record[0]
		fmt.Printf("Fetching company ratios for stock: %s\n", stockSymbol)

		// Fetch company ratios data for the stock
		data, err := fetchCompanyRatios(stockSymbol)
		if err != nil {
			log.Printf("Error fetching data for %s: %v", stockSymbol, err)
			continue
		}

		// Write the stock symbol and company ratios to the CSV file
		writer.Write([]string{data.StockSymbol, data.CompanyRatios})
	}

	fmt.Println("Data fetching complete. Output written to company_ratios.csv")
}
